#include "graph.h"

using namespace std;

int main() {
    Graph graph;
    createGraph(graph);

    // Rute dan mall
    string pascalRute[] = {"Telkom University", "Bojongsoang", "Jl. Nasional 3", "Moh Toha", "Jl. Astana Anyar"};
    string tsmRute[] = {"Telkom University", "Buah Batu", "Jl. Pelajar Pejuang", "Jl. Gatot Subroto"};
    string becRute[] = {"Telkom University", "Buah Batu", "Asia Afrika", "Taman Dewi Sartika", "Jl. Wastu Kencana"};

    string rutes[][5] = {
        {"Telkom University", "Bojongsoang", "Jl. Nasional 3", "Moh Toha", "Jl. Astana Anyar"}, // Pascal
        {"Telkom University", "Buah Batu", "Jl. Pelajar Pejuang", "Jl. Gatot Subroto"},         // TSM
        {"Telkom University", "Buah Batu", "Asia Afrika", "Taman Dewi Sartika", "Jl. Wastu Kencana"} // BEC
    };

    int ruteSizes[] = {5, 4, 5}; // Jumlah node per rute
    string malls[] = {"Pascal", "TSM", "BEC"};
    int distances[] = {15, 12, 10}; // Jarak masing-masing mall dalam km

    int pilihan;
    do {
        cout << "\n=== Menu ===\n";
        cout << "1. Tampilkan Rute ke Mall\n";
        cout << "2. Mall Terdekat\n";
        cout << "3. Mall Terdekat Hindari Wilayah\n";
        cout << "4. Keluar\n";
        cout << "Pilih menu: ";
        cin >> pilihan;

        if (pilihan == 1) {
            cout << "Pilih mall (1: Pascal, 2: TSM, 3: BEC): ";
            int mallPilihan;
            cin >> mallPilihan;
            if (mallPilihan == 1) {
                showGraphToMall(pascalRute, 5);
            } else if (mallPilihan == 2) {
                showGraphToMall(tsmRute, 4);
            } else if (mallPilihan == 3) {
                showGraphToMall(becRute, 5);
            } else {
                cout << "Pilihan tidak valid.\n";
            }
        } else if (pilihan == 2) {
            cout << "Mall terdekat: " << findShortestMall(malls, distances, 3) << endl;
        } else if (pilihan == 3) {
            string avoidArea;
            cout << "Masukkan wilayah yang ingin dihindari: ";
            cin >> avoidArea;
            findShortestPathWithAvoid(malls, rutes, ruteSizes, 3, avoidArea);
        }
    } while (pilihan != 4);

    cout << "Terima kasih!\n";
    return 0;
}
